import pdfplumber
import re
import csv
import sys
import os

def parse_pdf(pdf_path, year, output_csv, test_mode=False):
    print(f"Parsing {pdf_path} for year {year}...")
    
    records = []
    
    with pdfplumber.open(pdf_path) as pdf:
        pages_to_parse = pdf.pages[:5] if test_mode else pdf.pages
        
        college_name = ""
        branch_name = ""
        categories = []
        
        for page_num, page in enumerate(pages_to_parse):
            text = page.extract_text()
            if not text:
                continue
                
            lines = text.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # Match College Name: e.g. 01002 - Government College of Engineering, Amravati
                m_college = re.match(r'^\d{4,5}\s*-\s*(.+)$', line)
                if m_college:
                    college_name = m_college.group(1).strip()
                    continue
                
                # Match Branch Name: e.g. 0100219110 - Civil Engineering
                m_branch = re.match(r'^\d{9,10}\s*-\s*(.+)$', line)
                if m_branch:
                    branch_name = m_branch.group(1).strip()
                    continue
                
                # Match Category Headers
                if line.startswith("Stage "):
                    categories = line.split()[1:]
                    continue
                
                # Match Ranks (starts with I, II, or III)
                m_rank = re.match(r'^(I|II|III|IV)\s+(.+)$', line)
                if m_rank and categories:
                    stage_str = m_rank.group(1)
                    if stage_str == "I": # Focus on CAP 1 ranks
                        ranks_str = m_rank.group(2)
                        ranks = ranks_str.split()
                        
                        # We might have missing values or extra categories, zip up to the minimum
                        for cat, rank in zip(categories, ranks):
                            # Ensure rank is mostly digits
                            clean_rank = re.sub(r'[^\d]', '', rank)
                            if clean_rank:
                                records.append([college_name, branch_name, cat, clean_rank, year])
                    
                    # Optional: clear categories to avoid mismatched floating lines later
                    # categories = []
    
    # Append to CSV
    file_exists = os.path.isfile(output_csv)
    with open(output_csv, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(['College Name', 'Branch Name', 'Category', 'Rank', 'Year'])
        writer.writerows(records)
        
    print(f"Finished {pdf_path}. Extracted {len(records)} records.")

if __name__ == '__main__':
    test_only = '--test' in sys.argv
    csv_file = r'd:\CEP\cutoffs_master.csv'
    
    # If not testing, clear the old CSV if it exists
    if not test_only and os.path.exists(csv_file):
        os.remove(csv_file)
        
    pdfs = [
        (r'd:\CEP\2023 cap 1.pdf', 2023),
        (r'd:\CEP\2024ENGG_CAP1_CutOff.pdf', 2024),
        (r'd:\CEP\2025 cap1 cutoff.pdf', 2025)
    ]
    
    for pdf_path, year in pdfs:
        if os.path.exists(pdf_path):
            parse_pdf(pdf_path, year, csv_file, test_mode=test_only)
        else:
            print(f"Warning: File not found {pdf_path}")
            
    print(f"Done. Output saved to {csv_file}")
