import React, { useState } from 'react';
import { Target, Sparkles, Building2, Users, ArrowRight, Loader2, Award, BookOpen, Star } from 'lucide-react';
import api from '../lib/api';

export default function LandingPage() {
  const [formData, setFormData] = useState({
    percentile: '',
    totalStudents: '300000',
    rank: '',
    branch: '',
    district: '',
    category: ''
  });

  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');

  const handlePredict = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setResults(null);

    try {
      const response = await api.post('/colleges/predict', formData);
      setResults(response.data);
      // Smooth scroll to results on mobile
      setTimeout(() => {
        document.getElementById('results-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getChanceColor = (chance) => {
    if (chance.includes('Safe')) return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (chance.includes('Target')) return 'bg-blue-100 text-blue-700 border-blue-200';
    return 'bg-amber-100 text-amber-700 border-amber-200';
  };

  return (
    <div className="w-full bg-gray-50 min-h-screen pb-24">
      
      {/* Header/Hero for Mobile */}
      <div className="px-4 pt-10 pb-8 bg-white shadow-sm rounded-b-3xl relative z-10">
        <h1 className="text-3xl font-extrabold tracking-tight text-gray-900 mb-3 leading-tight">
          Find Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 to-blue-600">Dream College</span>
        </h1>
        <p className="text-sm text-gray-500 leading-relaxed">
          Predict your admissions based on exact historical MHT-CET cutoffs.
        </p>
      </div>

      {/* Main Predictor Container */}
      <div className="px-4 -mt-4 relative z-20">
        <div className="bg-white/80 backdrop-blur-xl border border-white/40 p-5 rounded-3xl shadow-xl">
          <form onSubmit={handlePredict} className="flex flex-col gap-5">
            
            {/* Rank Input */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1.5 uppercase tracking-wide">Your Merit Rank</label>
              <div className="relative">
                <Target className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input 
                  type="number" 
                  placeholder="e.g. 4500"
                  className="w-full pl-9 pr-4 py-3 rounded-2xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all text-sm bg-gray-50/50"
                  value={formData.rank}
                  onChange={e => setFormData({...formData, rank: e.target.value})}
                />
              </div>
            </div>

            {/* OR Divider */}
            <div className="flex items-center justify-center opacity-50">
              <div className="h-px bg-gray-300 flex-grow"></div>
              <span className="px-3 text-xs font-bold text-gray-500">OR CALCULATE</span>
              <div className="h-px bg-gray-300 flex-grow"></div>
            </div>

            {/* Percentile Input */}
            <div className="flex gap-3">
              <div className="w-1/2">
                <label className="block text-xs font-bold text-gray-700 mb-1.5 uppercase tracking-wide">Percentile</label>
                <input 
                  type="number" 
                  step="0.01"
                  placeholder="e.g. 95.5"
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all text-sm bg-gray-50/50"
                  value={formData.percentile}
                  onChange={e => setFormData({...formData, percentile: e.target.value})}
                />
              </div>
              <div className="w-1/2">
                <label className="block text-xs font-bold text-gray-700 mb-1.5 uppercase tracking-wide">
                  Total Students appeared in PCM group
                  <span className="text-[10px] text-gray-400 normal-case ml-1 font-medium">{'{you can search on browser}'}</span>
                </label>
                <input 
                  type="number" 
                  placeholder="e.g. 300000"
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all text-sm bg-gray-50/50"
                  value={formData.totalStudents}
                  onChange={e => setFormData({...formData, totalStudents: e.target.value})}
                />
              </div>
            </div>
            
            {/* Branch Selection */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1.5 uppercase tracking-wide">Branch</label>
              <select 
                required
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all text-sm bg-gray-50/50 appearance-none"
                value={formData.branch}
                onChange={e => setFormData({...formData, branch: e.target.value})}
              >
                <option value="">Select...</option>
                <option value="Computer Engineering">Computer Engg</option>
                <option value="Information Technology">Information Tech</option>
                <option value="Mechanical Engineering">Mechanical Engg</option>
                <option value="Civil Engineering">Civil Engg</option>
                <option value="Artificial Intelligence and Data Science">AI & DS</option>
              </select>
            </div>

            {/* Category Selection */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1.5 uppercase tracking-wide">Category</label>
              <select 
                required
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all text-sm bg-gray-50/50 appearance-none"
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value})}
              >
                <option value="">Select...</option>
                <option value="GOPENS">GOPENS (Open)</option>
                <option value="GOBCS">GOBCS (OBC)</option>
                <option value="GSCS">GSCS (SC)</option>
                <option value="GSTS">GSTS (ST)</option>
                <option value="EWS">EWS</option>
                <option value="TFWS">TFWS</option>
              </select>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs text-center font-medium">
                {error}
              </div>
            )}

            {/* Submit Button */}
            <button 
              type="submit" 
              disabled={isLoading}
              className="mt-2 w-full bg-gradient-to-r from-primary-600 to-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-primary-500/30 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Predict Matches
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* Results Section */}
      {results && (
        <div id="results-section" className="px-4 mt-10">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-extrabold text-gray-900">Your Matches</h2>
            <span className="text-xs font-bold bg-primary-100 text-primary-700 px-3 py-1 rounded-full">
              Rank: {results.user_rank}
            </span>
          </div>
          
          <div className="flex flex-col gap-4">
            {results.data.map((college, idx) => (
              <div key={idx} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
                <div className="flex justify-between items-start mb-3">
                  <span className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-lg border ${getChanceColor(college.admission_chance)}`}>
                    {college.admission_chance}
                  </span>
                  <span className="text-xs font-bold text-gray-400">Avg Cutoff: {college.avg_cutoff_rank}</span>
                </div>
                <h3 className="font-bold text-gray-900 text-sm leading-snug mb-1">{college.name}</h3>
                <p className="text-xs text-gray-500 mb-4 flex items-center gap-1">
                  <Building2 className="w-3 h-3" /> {college.district}
                </p>
                <button className="w-full py-2.5 bg-gray-50 hover:bg-gray-100 text-primary-600 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1">
                  View Full Insights <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            ))}
            {results.data.length === 0 && (
              <div className="text-center p-8 bg-white rounded-3xl border border-gray-100">
                <p className="text-sm text-gray-500">No colleges found matching this criteria.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Actions (Reviews & Compare Placeholders) */}
      <div className="px-4 mt-12 mb-8">
        <h2 className="text-lg font-extrabold text-gray-900 mb-4 px-1">Explore More</h2>
        
        <div className="grid grid-cols-2 gap-3">
          {/* Reviews Card */}
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-5 rounded-3xl shadow-lg relative overflow-hidden group active:scale-95 transition-transform">
            <div className="absolute top-0 right-0 p-3 opacity-20 group-hover:scale-110 transition-transform">
              <Star className="w-16 h-16 text-white" />
            </div>
            <div className="relative z-10 flex flex-col h-full justify-between gap-4">
              <div className="bg-white/20 w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md">
                <Users className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold text-sm">Senior Reviews</h3>
                <p className="text-indigo-100 text-[10px] mt-1 leading-tight">Read honest peer-vetted opinions</p>
              </div>
            </div>
          </div>

          {/* Compare Card */}
          <div className="bg-gradient-to-br from-rose-500 to-orange-500 p-5 rounded-3xl shadow-lg relative overflow-hidden group active:scale-95 transition-transform">
            <div className="absolute top-0 right-0 p-3 opacity-20 group-hover:scale-110 transition-transform">
              <BookOpen className="w-16 h-16 text-white" />
            </div>
            <div className="relative z-10 flex flex-col h-full justify-between gap-4">
              <div className="bg-white/20 w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md">
                <Award className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold text-sm">Compare</h3>
                <p className="text-rose-100 text-[10px] mt-1 leading-tight">Side-by-side college stats</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
