import csv
import psycopg2
from psycopg2.extras import execute_values
import os

DB_URL = "postgresql://cep_collalge_user:SRLluzZLvcJj3NbxfsWaRau5MqdJA23V@dpg-d7ltif3bc2fs738pi98g-a.ohio-postgres.render.com/cep_collalge?sslmode=require"
CSV_FILE = r"d:\CEP\cutoffs_master.csv"

def init_db(conn):
    print("Initializing database tables...")
    with conn.cursor() as cur:
        # Create Colleges Table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS colleges (
                id SERIAL PRIMARY KEY,
                name VARCHAR(500) NOT NULL,
                code VARCHAR(50),
                district VARCHAR(100),
                description TEXT
            );
        """)
        # Create Cutoffs Table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS cutoffs (
                id SERIAL PRIMARY KEY,
                college_id INT REFERENCES colleges(id),
                branch VARCHAR(500),
                category VARCHAR(50),
                rank INT,
                year INT
            );
        """)
        # Create Reviews Table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id SERIAL PRIMARY KEY,
                college_id INT REFERENCES colleges(id),
                student_name VARCHAR(100),
                is_verified BOOLEAN DEFAULT false,
                placement_rating INT CHECK (placement_rating BETWEEN 1 AND 5),
                faculty_rating INT CHECK (faculty_rating BETWEEN 1 AND 5),
                campus_rating INT CHECK (campus_rating BETWEEN 1 AND 5),
                review_text TEXT
            );
        """)
        conn.commit()

def seed_data(conn):
    print(f"Reading CSV from {CSV_FILE}...")
    
    colleges = {} # name -> id
    
    # 1. Gather distinct colleges
    with open(CSV_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cname = row['College Name']
            if cname not in colleges:
                colleges[cname] = None
    
    # 2. Insert colleges
    print(f"Inserting {len(colleges)} distinct colleges...")
    with conn.cursor() as cur:
        for cname in colleges.keys():
            # Check if exists to avoid duplicates if run multiple times
            cur.execute("SELECT id FROM colleges WHERE name = %s", (cname,))
            res = cur.fetchone()
            if res:
                colleges[cname] = res[0]
            else:
                cur.execute("INSERT INTO colleges (name, district) VALUES (%s, %s) RETURNING id", (cname, 'Maharashtra'))
                colleges[cname] = cur.fetchone()[0]
        conn.commit()
        
    # 3. Batch insert cutoffs
    print("Preparing cutoff records...")
    records = []
    with open(CSV_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            college_id = colleges[row['College Name']]
            branch = row['Branch Name']
            cat = row['Category']
            rank_str = row['Rank']
            year_str = row['Year']
            
            if rank_str.isdigit():
                records.append((college_id, branch, cat, int(rank_str), int(year_str)))
                
    print(f"Batch inserting {len(records)} cutoffs...")
    with conn.cursor() as cur:
        # Clear existing cutoffs to prevent duplication
        cur.execute("TRUNCATE TABLE cutoffs RESTART IDENTITY")
        
        insert_query = "INSERT INTO cutoffs (college_id, branch, category, rank, year) VALUES %s"
        execute_values(cur, insert_query, records, page_size=1000)
        conn.commit()

    print("Database seeding successfully completed!")

if __name__ == "__main__":
    print("Connecting to Render PostgreSQL database...")
    try:
        conn = psycopg2.connect(DB_URL)
        init_db(conn)
        seed_data(conn)
        conn.close()
    except Exception as e:
        print("An error occurred:", e)
