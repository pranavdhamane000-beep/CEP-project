const { Pool } = require('pg');
const fs = require('fs');
// const csv = require('csv-parser'); // You would need to run: npm install csv-parser
require('dotenv').config({ path: '../.env' });

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

// Example function to insert a college manually
const seedData = async () => {
  try {
    console.log('Connecting to database...');
    
    // 1. Insert College
    const collegeQuery = `
      INSERT INTO colleges (name, code, district, description) 
      VALUES ($1, $2, $3, $4) RETURNING id;
    `;
    const collegeValues = ['Pune Institute of Computer Technology', 'PICT', 'Pune', 'Top engineering college in Pune.'];
    const collegeRes = await pool.query(collegeQuery, collegeValues);
    const collegeId = collegeRes.rows[0].id;
    console.log(`Inserted college with ID: ${collegeId}`);

    // 2. Insert Cutoff for that college
    const cutoffQuery = `
      INSERT INTO cutoffs (college_id, branch, category, rank, year) 
      VALUES ($1, $2, $3, $4, $5);
    `;
    const cutoffValues = [collegeId, 'Computer Science', 'Open', 1500, 2023];
    await pool.query(cutoffQuery, cutoffValues);
    console.log('Inserted cutoff data.');

    console.log('Data seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding data:', error);
  } finally {
    pool.end();
  }
};

seedData();
