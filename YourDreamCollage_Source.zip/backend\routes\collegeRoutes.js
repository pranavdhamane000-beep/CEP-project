const express = require('express');
const router = express.Router();
const { predictColleges, getCollegeDetails, addReview } = require('../controllers/collegeController');

router.post('/predict', predictColleges);
router.get('/:id', getCollegeDetails);
router.post('/:id/reviews', addReview);

module.exports = router;
