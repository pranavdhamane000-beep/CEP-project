import React from 'react';
import { GraduationCap, Search, User } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 glass-card px-6 py-4 flex items-center justify-between">
      <Link to="/" className="flex items-center gap-2 group">
        <div className="bg-primary-600 p-2 rounded-xl group-hover:scale-105 transition-transform shadow-lg shadow-primary-500/30">
          <GraduationCap className="text-white w-6 h-6" />
        </div>
        <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-700 to-primary-500">
          YourDream Collage
        </span>
      </Link>
      
      <div className="hidden md:flex items-center space-x-8 font-medium text-gray-600">
        <Link to="/" className="hover:text-primary-600 transition-colors">Home</Link>
        <Link to="/compare" className="hover:text-primary-600 transition-colors">Compare</Link>
        <Link to="/reviews" className="hover:text-primary-600 transition-colors">Reviews</Link>
      </div>

      <div className="flex items-center space-x-4">
        <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <Search className="w-5 h-5 text-gray-600" />
        </button>
        <button className="flex items-center gap-2 bg-gray-900 text-white px-5 py-2.5 rounded-full hover:bg-gray-800 transition-all hover:shadow-lg hover:shadow-gray-900/20">
          <User className="w-4 h-4" />
          <span className="text-sm font-medium">Sign In</span>
        </button>
      </div>
    </nav>
  );
}
