const db = require('../config/db');

// @desc    Predict colleges based on percentile, branch, and category
// @route   POST /api/colleges/predict
const predictColleges = async (req, res, next) => {
  try {
    const { percentile, totalStudents, rank, branch, category, district } = req.body;

    let calculatedRank = rank;

    if (!calculatedRank && percentile && totalStudents) {
      calculatedRank = Math.floor(((100 - parseFloat(percentile)) * parseInt(totalStudents)) / 100);
    }

    if (!calculatedRank || !branch || !category) {
      return res.status(400).json({ success: false, message: 'Please provide either Rank OR (Percentile and Total Students), along with Branch and Category.' });
    }

    // Algorithm: Aggregates historical cutoff ranks over the years (2023, 2024, 2025).
    // Uses Average cutoff + 2000 leeway to predict possibilities.
    let queryStr = `
      SELECT 
        c.id, 
        c.name, 
        c.district, 
        cut.branch, 
        cut.category, 
        ROUND(AVG(cut.rank)) as avg_cutoff_rank,
        MIN(cut.rank) as highest_cutoff,
        MAX(cut.rank) as lowest_cutoff
      FROM colleges c
      JOIN cutoffs cut ON c.id = cut.college_id
      WHERE cut.branch = $1 AND cut.category = $2
    `;
    const params = [branch, category];

    if (district) {
      queryStr += ` AND c.district = $3`;
      params.push(district);
    }

    queryStr += ` 
      GROUP BY c.id, c.name, c.district, cut.branch, cut.category
      HAVING $${params.length + 1} <= (AVG(cut.rank) + 2000)
      ORDER BY avg_cutoff_rank ASC 
      LIMIT 10
    `;
    params.push(calculatedRank);

    const { rows } = await db.query(queryStr, params);

    // Advanced Logic: Classify Admission Chance based on historical standard deviation
    const predictions = rows.map(row => {
      let chance = "Moderate (Target)";
      if (calculatedRank <= row.avg_cutoff_rank - 1000) {
        chance = "High (Safe)";
      } else if (calculatedRank > row.avg_cutoff_rank + 500) {
        chance = "Low (Reach)";
      }
      return { ...row, admission_chance: chance };
    });

    res.status(200).json({ success: true, user_rank: calculatedRank, data: predictions });
  } catch (error) {
    next(error);
  }
};

// @desc    Get details of a specific college including cutoffs and reviews
// @route   GET /api/colleges/:id
const getCollegeDetails = async (req, res, next) => {
  try {
    const { id } = req.params;

    const collegeQuery = await db.query('SELECT * FROM colleges WHERE id = $1', [id]);
    if (collegeQuery.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'College not found' });
    }

    const cutoffsQuery = await db.query('SELECT * FROM cutoffs WHERE college_id = $1 ORDER BY year DESC', [id]);
    const reviewsQuery = await db.query('SELECT * FROM reviews WHERE college_id = $1 ORDER BY id DESC', [id]);

    res.status(200).json({
      success: true,
      data: {
        college: collegeQuery.rows[0],
        cutoffs: cutoffsQuery.rows,
        reviews: reviewsQuery.rows
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Add a senior review for a college
// @route   POST /api/colleges/:id/reviews
const addReview = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { student_name, is_verified, placement_rating, faculty_rating, campus_rating, review_text } = req.body;

    const insertQuery = `
      INSERT INTO reviews (college_id, student_name, is_verified, placement_rating, faculty_rating, campus_rating, review_text)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;

    const { rows } = await db.query(insertQuery, [
      id, student_name, is_verified, placement_rating, faculty_rating, campus_rating, review_text
    ]);

    res.status(201).json({ success: true, data: rows[0] });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  predictColleges,
  getCollegeDetails,
  addReview
};
